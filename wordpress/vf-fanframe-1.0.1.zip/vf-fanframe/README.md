# VF FanFrame Integration

## 📝 Descrição
O plugin **VF FanFrame Integration** faz a ponte entre a carteira de créditos de Inteligência Artificial do usuário no WordPress e a geração de fotos realistas no FanFrame (gerador de fotos com IA nos Tours Virtuais).

---

## 🧩 Shortcodes Disponíveis
*   `[vf_fanframe_credits_box]` - Renderiza a caixinha flutuante com a quantidade de créditos de IA restantes do usuário, exibindo o dropdown para comprar novos pacotes ou acessar o Memorial (gerador).

---

## ⚙️ Configuração de Links e Packs
Os links de compra redirecionam para a página `/buy-credits` passando os parâmetros de pacotes (`?pack=1`, `?pack=3`, `?pack=7`), que são processados pelo WooCommerce.

O link do gerador de fotos aponta para `/tour/?tour=memorial` utilizando a chamada dinâmica de `home_url()`.

---

## 🔄 Processo de Duplicação (White-Label)
Ao clonar o projeto para outro clube:
1.  **Não altere o código do plugin.**
2.  Garanta que a página `/tour/?tour=memorial` ou equivalente exista no novo clube.
3.  Cadastre os produtos correspondentes aos pacotes de créditos (pack 1, 3 e 7) no WooCommerce do novo clube e configure a regra de redirecionamento correspondente.
