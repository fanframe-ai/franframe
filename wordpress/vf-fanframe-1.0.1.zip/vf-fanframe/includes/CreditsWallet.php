<?php
namespace VFFanframe;

if (!defined('ABSPATH')) exit;

class CreditsWallet {

    public static function getBalance(int $user_id): int {
        $db = Database::ext();
        $bal = $db->get_var($db->prepare(
            "SELECT balance FROM vf_ff_image_credits_wallet WHERE user_id=%d",
            $user_id
        ));
        return intval($bal ?? 0);
    }

    public static function ensureWallet(int $user_id): void {
        $db = Database::ext();
        $db->query($db->prepare(
            "INSERT IGNORE INTO vf_ff_image_credits_wallet (user_id, balance) VALUES (%d, 0)",
            $user_id
        ));
    }

    /**
     * Debita 1 crédito com idempotência por generation_id (ref gen:{id})
     * Retorna array: [ok=>bool, reason?=>string, balance_after?=>int]
     */
    public static function debitOne(int $user_id, string $generation_id): array {
        $db = Database::ext();
        $ref = 'gen:' . $generation_id;

        // idempotência rápida (fora da transação)
        $exists = $db->get_var($db->prepare(
            "SELECT id FROM vf_ff_image_credits_ledger WHERE ref=%s LIMIT 1",
            $ref
        ));
        if ($exists) {
            return [
                'ok' => true,
                'balance_after' => self::getBalance($user_id),
                'idempotent' => true
            ];
        }

        $now = current_time('mysql');

        $db->query('START TRANSACTION');

        try {
            self::ensureWallet($user_id);

            // lock na wallet
            $row = $db->get_row($db->prepare(
                "SELECT balance FROM vf_ff_image_credits_wallet WHERE user_id=%d FOR UPDATE",
                $user_id
            ), ARRAY_A);

            $balance = intval($row['balance'] ?? 0);

            // recheck idempotência dentro da transação (race)
            $exists2 = $db->get_var($db->prepare(
                "SELECT id FROM vf_ff_image_credits_ledger WHERE ref=%s LIMIT 1",
                $ref
            ));
            if ($exists2) {
                $db->query('COMMIT');
                return [
                    'ok' => true,
                    'balance_after' => $balance,
                    'idempotent' => true
                ];
            }

            if ($balance <= 0) {
                $db->query('ROLLBACK');
                return ['ok' => false, 'reason' => 'no_credits'];
            }

            // debita
            $upd = $db->query($db->prepare(
                "UPDATE vf_ff_image_credits_wallet SET balance = balance - 1 WHERE user_id=%d",
                $user_id
            ));
            if ($upd === false) {
                throw new \Exception('wallet_update_failed');
            }

            // ledger (UNIQUE ref garante idempotência)
            $ins = $db->insert('vf_ff_image_credits_ledger', [
                'user_id'    => $user_id,
                'direction'  => 'debit',
                'amount'     => 1,
                'source'     => 'generation',
                'ref'        => $ref,
                'metadata'   => json_encode(['generation_id' => $generation_id]),
                'created_at' => $now
            ], ['%d','%s','%d','%s','%s','%s','%s']);

            if ($ins === false) {
                // Se falhou por duplicate, tratar como idempotente
                if (stripos($db->last_error, 'Duplicate') !== false) {
                    $db->query('ROLLBACK');
                    return [
                        'ok' => true,
                        'balance_after' => self::getBalance($user_id),
                        'idempotent' => true
                    ];
                }
                throw new \Exception('ledger_insert_failed: ' . $db->last_error);
            }

            // saldo final
            $balance_after = $db->get_var($db->prepare(
                "SELECT balance FROM vf_ff_image_credits_wallet WHERE user_id=%d",
                $user_id
            ));

            $db->query('COMMIT');

            return [
                'ok' => true,
                'balance_after' => intval($balance_after)
            ];

        } catch (\Throwable $e) {
            $db->query('ROLLBACK');
            return ['ok' => false, 'reason' => 'server_error', 'detail' => $e->getMessage()];
        }
    }
}