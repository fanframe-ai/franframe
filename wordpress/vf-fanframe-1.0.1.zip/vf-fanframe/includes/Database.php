<?php
namespace VFFanframe;
if (!defined('ABSPATH')) exit;

class Database {
    private static $ext = null;

    public static function ext(): \wpdb {
        if (self::$ext instanceof \wpdb) return self::$ext;

        $db = new \wpdb(EXT_DB_USER, EXT_DB_PASS, EXT_DB_NAME, EXT_DB_HOST);
        $db->set_charset($db->dbh, EXT_DB_CHARSET ?? 'utf8mb4');
        $db->hide_errors();

        self::$ext = $db;
        return self::$ext;
    }
}
