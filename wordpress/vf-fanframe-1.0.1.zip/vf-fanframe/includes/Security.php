<?php
namespace VFFanframe;

if (!defined('ABSPATH')) exit;

class Security {

    public static function getBearerToken(): ?string {
        $h = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
        if (!$h) return null;

        if (stripos($h, 'Bearer ') === 0) {
            $t = trim(substr($h, 7));
            return $t !== '' ? $t : null;
        }
        return null;
    }

    public static function requireUserId() {
        // 1) Preferir app_token (Lovable)
        $token = self::getBearerToken();
        if ($token) {
            $user_id = self::userIdFromAppToken($token);
            if ($user_id) return $user_id;
            return new \WP_Error('unauthorized', 'Invalid or expired token', ['status' => 401]);
        }

        // 2) Fallback para testes no WP (browser logado)
        $uid = get_current_user_id();
        if ($uid) return $uid;

        return new \WP_Error('unauthorized', 'Missing token', ['status' => 401]);
    }

    public static function userIdFromAppToken(string $token): ?int {
        $db = Database::ext();
        $hash = hash('sha256', $token);
        $now = current_time('mysql');

        $row = $db->get_row(
            $db->prepare(
                "SELECT id, user_id FROM vf_ff_app_sessions
                 WHERE token_hash=%s
                   AND revoked_at IS NULL
                   AND expires_at > %s
                 LIMIT 1",
                $hash, $now
            ),
            ARRAY_A
        );

        if (!$row) return null;

        // last_seen (best effort)
        $db->update(
            'vf_ff_app_sessions',
            ['last_seen_at' => $now],
            ['id' => intval($row['id'])],
            ['%s'],
            ['%d']
        );

        return intval($row['user_id']);
    }
}