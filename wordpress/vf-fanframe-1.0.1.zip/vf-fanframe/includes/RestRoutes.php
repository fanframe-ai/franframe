<?php
namespace VFFanframe;

if (!defined('ABSPATH')) exit;

class RestRoutes {

    public static function register(): void {

        add_action('rest_api_init', function () {

            register_rest_route('vf-fanframe/v1', '/handoff/exchange', [
                'methods'  => ['POST', 'OPTIONS'],
                'permission_callback' => '__return_true',
                'callback' => function (\WP_REST_Request $req) {
                    Cors::apply();

                    $code = (string) $req->get_param('code');
                    $code = trim($code);

                    if ($code === '') {
                        return new \WP_Error('bad_request', 'Missing code', ['status' => 400]);
                    }

                    try {
                        $ex = HandoffService::exchange($code, 86400);
                        $balance = CreditsWallet::getBalance(intval($ex['user_id']));

                        return [
                            'ok' => true,
                            'app_token' => $ex['app_token'],
                            'user_id' => $ex['user_id'],
                            'expires_at' => $ex['expires_at'],
                            'balance' => $balance
                        ];
                    } catch (\Throwable $e) {
                        if (in_array($e->getMessage(), ['invalid_code', 'code_consumed', 'code_expired'], true)) {
                            return new \WP_Error('unauthorized', $e->getMessage(), ['status' => 401]);
                        }
                        return new \WP_Error('server_error', 'FanFrame session storage failed', ['status' => 500]);
                    }
                }
            ]);

            register_rest_route('vf-fanframe/v1', '/credits/balance', [
                'methods'  => ['GET', 'OPTIONS'],
                'permission_callback' => '__return_true',
                'callback' => function () {
                    Cors::apply();

                    $uid = Security::requireUserId();
                    if (is_wp_error($uid)) return $uid;

                    return [
                        'ok' => true,
                        'balance' => CreditsWallet::getBalance(intval($uid))
                    ];
                }
            ]);

            register_rest_route('vf-fanframe/v1', '/credits/debit', [
                'methods'  => ['POST', 'OPTIONS'],
                'permission_callback' => '__return_true',
                'callback' => function (\WP_REST_Request $req) {
                    Cors::apply();

                    $uid = Security::requireUserId();
                    if (is_wp_error($uid)) return $uid;

                    $gen = (string) $req->get_param('generation_id');
                    $gen = trim($gen);

                    if ($gen === '') {
                        return new \WP_Error('bad_request', 'Missing generation_id', ['status' => 400]);
                    }

                    $res = CreditsWallet::debitOne(intval($uid), $gen);

                    if (!$res['ok'] && ($res['reason'] ?? '') === 'no_credits') {
                        return [
                            'ok' => false,
                            'reason' => 'no_credits'
                        ];
                    }

                    if (!$res['ok']) {
                        return new \WP_Error('server_error', $res['reason'] ?? 'error', ['status' => 500]);
                    }

                    return $res;
                }
            ]);

        });
    }
}
