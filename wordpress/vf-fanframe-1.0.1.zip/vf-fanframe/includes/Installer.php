<?php
namespace VFFanframe;
if (!defined('ABSPATH')) exit;

class Installer {
    public static function install() {
        $db = Database::ext();
        if ($db->query("CREATE TABLE IF NOT EXISTS vf_ff_image_credits_wallet (
            user_id BIGINT UNSIGNED NOT NULL,
            balance INT NOT NULL DEFAULT 0,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (user_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4") === false) {
            throw new \RuntimeException('wallet_table_install_failed');
        }

        if ($db->query("CREATE TABLE IF NOT EXISTS vf_ff_image_credits_ledger (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_id BIGINT UNSIGNED NOT NULL,
            direction ENUM('credit','debit') NOT NULL,
            amount INT NOT NULL,
            source VARCHAR(50) NOT NULL,
            ref VARCHAR(120) NOT NULL UNIQUE,
            metadata JSON NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4") === false) {
            throw new \RuntimeException('ledger_table_install_failed');
        }

        if ($db->query("CREATE TABLE IF NOT EXISTS vf_ff_handoff_codes (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            code_hash CHAR(64) NOT NULL UNIQUE,
            user_id BIGINT UNSIGNED NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            expires_at DATETIME NOT NULL,
            consumed_at DATETIME NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4") === false) {
            throw new \RuntimeException('handoff_table_install_failed');
        }

        if ($db->query("CREATE TABLE IF NOT EXISTS vf_ff_app_sessions (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            session_id CHAR(36) NOT NULL UNIQUE,
            token_hash CHAR(64) NOT NULL UNIQUE,
            user_id BIGINT UNSIGNED NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            expires_at DATETIME NOT NULL,
            last_seen_at DATETIME NULL,
            revoked_at DATETIME NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4") === false) {
            throw new \RuntimeException('session_table_install_failed');
        }

        // CREATE IF NOT EXISTS does not repair tables from earlier versions.
        $column = $db->get_row("SHOW COLUMNS FROM vf_ff_app_sessions LIKE 'last_seen_at'");
        if ($db->last_error !== '') {
            throw new \RuntimeException('session_schema_read_failed');
        }
        if (!$column && $db->query('ALTER TABLE vf_ff_app_sessions ADD COLUMN last_seen_at DATETIME NULL') === false) {
            throw new \RuntimeException('session_schema_upgrade_failed');
        }
    }
}
