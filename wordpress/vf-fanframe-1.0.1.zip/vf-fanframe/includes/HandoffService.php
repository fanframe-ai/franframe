<?php
namespace VFFanframe;

if (!defined('ABSPATH')) exit;

class HandoffService {

    public static function createCode(int $user_id, int $ttl_seconds = 1200): string {
        $code = bin2hex(random_bytes(32));
        $hash = hash('sha256', $code);
        $expires = date('Y-m-d H:i:s', time() + $ttl_seconds);

        $saved = Database::ext()->insert('vf_ff_handoff_codes', [
            'code_hash'   => $hash,
            'user_id'     => $user_id,
            'expires_at'  => $expires,
            'created_at'  => current_time('mysql'),
            'consumed_at' => null,
        ]);

        if ($saved === false) {
            throw new \RuntimeException('handoff_write_failed');
        }

        return $code;
    }

    public static function exchange(string $code, int $session_ttl_seconds = 86400): array {
        $db = Database::ext();
        $hash = hash('sha256', $code);
        $now = current_time('mysql');

        if ($db->query('START TRANSACTION') === false) {
            throw new \RuntimeException('transaction_failed');
        }

        try {
            $row = $db->get_row(
                $db->prepare(
                    "SELECT id, user_id, expires_at, consumed_at
                     FROM vf_ff_handoff_codes
                     WHERE code_hash=%s
                     LIMIT 1 FOR UPDATE",
                    $hash
                ),
                ARRAY_A
            );

            if ($db->last_error !== '') {
                throw new \RuntimeException('handoff_read_failed');
            }

            if (!$row) {
                throw new \Exception('invalid_code');
            }

            if (!empty($row['consumed_at'])) {
                throw new \Exception('code_consumed');
            }

            if ($row['expires_at'] <= $now) {
                throw new \Exception('code_expired');
            }

            // marca consumido
            $consumed = $db->update(
                'vf_ff_handoff_codes',
                ['consumed_at' => $now],
                ['id' => intval($row['id'])],
                ['%s'],
                ['%d']
            );
            if ($consumed !== 1) {
                throw new \RuntimeException('handoff_consume_failed');
            }

            $user_id = intval($row['user_id']);

            // revoga sessões anteriores do mesmo usuário (evita token antigo desatualizado)
            $revoked = $db->query($db->prepare(
                "UPDATE vf_ff_app_sessions SET revoked_at=%s
                 WHERE user_id=%d AND revoked_at IS NULL",
                $now, $user_id
            ));
            if ($revoked === false) {
                throw new \RuntimeException('session_revoke_failed');
            }

            // cria sessão (token armazenado como hash)
            $token = bin2hex(random_bytes(32));
            $token_hash = hash('sha256', $token);

            $session_id = self::uuidv4();
            $expires_at = date('Y-m-d H:i:s', time() + $session_ttl_seconds);

            $saved = $db->insert('vf_ff_app_sessions', [
                'session_id'   => $session_id,
                'token_hash'   => $token_hash,
                'user_id'      => $user_id,
                'created_at'   => $now,
                'expires_at'   => $expires_at,
                'last_seen_at' => $now,
                'revoked_at'   => null,
            ]);
            if ($saved === false) {
                throw new \RuntimeException('session_write_failed');
            }

            if ($db->query('COMMIT') === false) {
                throw new \RuntimeException('transaction_failed');
            }

            return [
                'app_token' => $token,
                'user_id'   => $user_id,
                'expires_at'=> $expires_at,
            ];

        } catch (\Throwable $e) {
            $db->query('ROLLBACK');
            throw $e;
        }
    }

    private static function uuidv4(): string {
        $data = random_bytes(16);
        $data[6] = chr((ord($data[6]) & 0x0f) | 0x40);
        $data[8] = chr((ord($data[8]) & 0x3f) | 0x80);
        return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
    }
}
