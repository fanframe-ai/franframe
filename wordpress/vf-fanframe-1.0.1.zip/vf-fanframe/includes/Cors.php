<?php
namespace VFFanframe;

if (!defined('ABSPATH')) exit;

class Cors {
    const ALLOWED_ORIGINS = [
        'https://ffcorinthians.lovable.app',
        'https://tricolorvirtualexperience.net',
        'https://franframe.vercel.app',
    ];

    public static function getAllowedOrigins(): array {
        $origins = self::ALLOWED_ORIGINS;

        if (defined('VF_FANFRAME_APP_URL')) {
            $parsed = wp_parse_url(VF_FANFRAME_APP_URL);
            if (!empty($parsed['scheme']) && !empty($parsed['host'])) {
                $port = !empty($parsed['port']) ? ':' . $parsed['port'] : '';
                $appOrigin = $parsed['scheme'] . '://' . $parsed['host'] . $port;
                if (!in_array($appOrigin, $origins, true)) {
                    $origins[] = $appOrigin;
                }
            }
        }

        return $origins;
    }

    public static function apply(): void {
        $origin = $_SERVER['HTTP_ORIGIN'] ?? '';

        if (in_array($origin, self::getAllowedOrigins(), true)) {
            header('Access-Control-Allow-Origin: ' . $origin);
            header('Vary: Origin');
            header('Access-Control-Allow-Headers: Authorization, Content-Type, X-Requested-With, authorization, content-type');
            header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
        }
    }
}
