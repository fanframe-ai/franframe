<?php
namespace VFFanframe;

if (!defined('ABSPATH')) exit;

class IframePage {
    public static function register(): void {
        add_shortcode('vf_fanframe_iframe', [self::class, 'render']);
    }

    public static function getUrl(int $user_id = 0): string {
        if (!$user_id) {
            $user_id = get_current_user_id();
        }
        if (!$user_id) {
            return '';
        }

        // code com TTL 20 min
        $code = HandoffService::createCode($user_id, 1200);

        $appUrl = defined('VF_FANFRAME_APP_URL') ? VF_FANFRAME_APP_URL : 'https://ffcorinthians.lovable.app/';
        return add_query_arg(['code' => $code], $appUrl);
    }

    public static function render(): string {
        if (!is_user_logged_in()) {
            $login = wp_login_url(get_permalink());
            wp_safe_redirect($login);
            exit;
        }

        $src = self::getUrl(get_current_user_id());

        // iframe 100% tela
        return '
<style>
html, body { margin:0 !important; padding:0 !important; height:100% !important; overflow:hidden !important; }
#vf-fanframe-wrap { position:fixed; inset:0; width:100vw; height:100vh; background:#000; z-index:999999; }
#vf-fanframe-iframe { width:100%; height:100%; border:0; display:block; }
</style>
<div id="vf-fanframe-wrap">
  <iframe id="vf-fanframe-iframe" src="'.esc_url($src).'" allow="camera; microphone; clipboard-read; clipboard-write" sandbox="allow-scripts allow-same-origin allow-top-navigation-by-user-activation allow-popups"></iframe>
</div>';
    }
}