<?php
/**
 * Plugin Name: VF Fanframe
 * Description: Créditos FanFrame + handoff seguro WP -> Lovable.
 * Version: 1.0.1
 * Author: VF / Timão Virtual Experience
 */

if (!defined('ABSPATH')) exit;

if (!defined('VF_FANFRAME_PATH')) {
    define('VF_FANFRAME_PATH', plugin_dir_path(__FILE__));
}

if (!defined('VF_FANFRAME_URL')) {
    define('VF_FANFRAME_URL', plugin_dir_url(__FILE__));
}

if (!defined('VF_FANFRAME_APP_URL')) {
    define('VF_FANFRAME_APP_URL', 'https://franframe.vercel.app/saopaulo-sp7k2x');
}

if (!defined('VF_FANFRAME_TAG_ID')) {
    define('VF_FANFRAME_TAG_ID', '765559');
}

define('VF_FANFRAME_FILE', __FILE__);

require_once VF_FANFRAME_PATH . 'includes/Database.php';
require_once VF_FANFRAME_PATH . 'includes/Installer.php';
require_once VF_FANFRAME_PATH . 'includes/Cors.php';
require_once VF_FANFRAME_PATH . 'includes/Security.php';
require_once VF_FANFRAME_PATH . 'includes/HandoffService.php';
require_once VF_FANFRAME_PATH . 'includes/CreditsWallet.php';
require_once VF_FANFRAME_PATH . 'includes/RestRoutes.php';
require_once VF_FANFRAME_PATH . 'includes/IframePage.php';

register_activation_hook(VF_FANFRAME_FILE, function () {
    \VFFanframe\Installer::install();
});

add_action('plugins_loaded', function () {
    \VFFanframe\RestRoutes::register();
    \VFFanframe\IframePage::register();
});
add_action('rest_api_init', function () {
    add_filter('rest_pre_serve_request', function ($served, $result, $request, $server) {
        $route = $request->get_route(); // ex: /vf-fanframe/v1/credits/balance

        // Só aplica para nossas rotas
        if (strpos($route, '/vf-fanframe/v1/') === 0) {
            \VFFanframe\Cors::apply();

            // Se for preflight, responder aqui mesmo
            if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
                status_header(200);
                echo '';
                return true; // já serviu a resposta
            }
        }

        return $served;
    }, 10, 4);
});

add_shortcode('vf_fanframe_credits_box', function () {

    $userId  = get_current_user_id();
    $balance = 0;

    if ($userId) {
        if (class_exists('\VFFanframe\CreditsWallet')) {
            $balance = \VFFanframe\CreditsWallet::getBalance($userId);
        } else {
            global $st_db;
            if ($st_db) {
                $balance = (int) $st_db->get_var(
                    $st_db->prepare(
                        "SELECT balance 
                         FROM vf_ff_image_credits_wallet 
                         WHERE user_id = %d",
                        $userId
                    )
                );
            }
        }
    }

    $balanceFormatted = number_format($balance, 0, ',', '.');
    $iconUrl = VF_FANFRAME_URL . 'public/assets/credit.png';

    ob_start();
    ?>
    <style>
        .vf-ff-credits-box {
            position: relative;
            display: inline-flex;
            align-items: center;
            justify-content: space-between;
            min-width: 100px;
            height: 48px;
            padding: 10px 8px;
            border: 1px solid rgba(255, 255, 255, .18);
            color: #fff;
            box-sizing: border-box;
            cursor: pointer;
            user-select: none;
            transition: border-color 0.2s, background-color 0.2s;
        }

        .vf-ff-credits-box:hover {
            border-color: rgba(255, 255, 255, 0.4);
        }

        .vf-ff-credits-box .vf-points-icon {
            width: 44px;
            height: 44px;
            display: flex;
            align-items: center;
            justify-content: flex-start;
        }

        .vf-ff-credits-box .vf-points-icon img {
            width: 25px;
            object-fit: contain;
            filter: drop-shadow(0 2px 6px rgba(0,0,0,.4));
        }

        .vf-ff-credits-box .vf-points-left {
            align-items: baseline;
            text-align: end;
        }

        .vf-ff-credits-box .vf-points-value {
            font-size: 22px;
            font-weight: 800;
            line-height: 1;
            font-family: var(--theme-font-menu_font-family);
        }

        .vf-ff-credits-box .vf-points-label {
            font-size: 12px;
            font-weight: 400;
            opacity: .7;
            line-height: 1;
            font-family: var(--theme-font-menu_font-family);
        }

        .vf-ff-credits-dropdown {
            position: absolute;
            top: 78px;
            right: 0;
            min-width: 220px;
            background: #000;
            padding: 8px;
            z-index: 99999;
            opacity: 0;
            visibility: hidden;
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.8);
            transition: opacity .25s ease, visibility .25s ease;
        }

        .vf-ff-credits-dropdown.is-visible {
            opacity: 1;
            visibility: visible;
        }

        .vf-ff-credits-dropdown .vf-link {
            display: block;
            padding: 10px 12px;
            border-radius: 6px;
            text-decoration: none;
            color: #e4e4e4 !important;
            font-size: 13px;
            transition: background .2s ease, color .2s ease;
        }

        .vf-ff-credits-dropdown .vf-link:hover {
            background: rgba(255, 255, 255, 0.08);
            color: #F1AF07 !important;
        }
        
        .vf-ff-credits-info {
            font-size: 12px;
            line-height: 1.45;
            color: rgba(255,255,255,.75);
            padding: 10px 12px;
            margin-bottom: 6px;
            border-bottom: 1px solid rgba(255,255,255,.12);
            cursor: default;
        }
        
        .vf-ff-credits-info strong {
            display: block;
            font-size: 13px;
            margin-bottom: 4px;
            color: #fff;
        }
    </style>

    <div class="vf-ff-credits-box">
        <div class="vf-points-icon">
            <img src="<?php echo esc_url($iconUrl); ?>" alt="Créditos">
        </div>
        <div class="vf-points-left">
            <div class="vf-points-value"><?php echo esc_html($balanceFormatted); ?></div>
            <div class="vf-points-label">CRÉDITOS</div>
        </div>
        <div class="vf-ff-credits-dropdown">
            <div class="vf-ff-credits-info">
                <strong>Créditos FanFrame</strong>
                Eles permitem gerar fotos realistas com IA dentro dos Tours Virtuais.
            </div>

            <a class="vf-link" href="<?php echo esc_url(home_url('/buy-credits?pack=1')); ?>">Comprar 1 crédito</a>
            <a class="vf-link" href="<?php echo esc_url(home_url('/buy-credits?pack=3')); ?>">Comprar 3 créditos</a>
            <a class="vf-link" href="<?php echo esc_url(home_url('/buy-credits?pack=7')); ?>">Comprar 7 créditos</a>
        </div>
    </div>

    <script>
    (function(){
        document.querySelectorAll('.vf-ff-credits-box').forEach(box => {
            if (box.dataset.vfBound === '1') return;
            box.dataset.vfBound = '1';

            const dropdown = box.querySelector('.vf-ff-credits-dropdown');
            let hideTimeout = null;

            const show = () => {
                if (hideTimeout) clearTimeout(hideTimeout);
                dropdown.classList.add('is-visible');
            };

            const hide = () => {
                hideTimeout = setTimeout(() => {
                    dropdown.classList.remove('is-visible');
                }, 300);
            };

            box.addEventListener('mouseenter', show);
            box.addEventListener('mouseleave', hide);
            dropdown.addEventListener('mouseenter', show);
            dropdown.addEventListener('mouseleave', hide);
        });
    })();
    </script>
    <?php

    return ob_get_clean();
});
