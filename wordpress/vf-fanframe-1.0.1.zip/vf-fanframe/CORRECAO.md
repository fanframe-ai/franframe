# Correcao de login 1.0.1

O original retornava um codigo mesmo se o INSERT em vf_ff_handoff_codes falhasse.
A troca depois retornava invalid_code, escondendo a falha de banco. Agora a
criacao interrompe a operacao se o codigo nao foi salvo. Erros de armazenamento
na troca retornam HTTP 500, enquanto codigo desconhecido, consumido ou expirado
continua retornando HTTP 401. Nenhum detalhe de banco ou senha e exposto na API.

O instalador original tambem nao criava last_seen_at em vf_ff_app_sessions,
embora o login gravasse esse campo. A ativacao agora cria ou adiciona a coluna
sem apagar carteiras, saldo, historico ou sessoes. Falhas de criacao de tabelas
nao sao mais ignoradas. A troca usa lock na linha e verifica as gravacoes antes
de confirmar a transacao, preservando o codigo e a sessao anterior se falhar.

## Instalacao pelo administrador WordPress

1. Faca backup do plugin atual e do banco externo de creditos.
2. Substitua o plugin pelo ZIP vf-fanframe-corrigido-1.0.1.zip, sem desinstalar
   nem apagar tabelas. Confirme que existe apenas uma copia ativa do plugin.
3. Desative e reative VF Fanframe para executar o instalador atualizado.
4. Se a ativacao falhar, confira EXT_DB_USER, EXT_DB_PASS, EXT_DB_NAME e
   EXT_DB_HOST no servidor. O usuario do banco externo precisa das permissoes
   usadas pelo plugin: CREATE, ALTER, SELECT, INSERT e UPDATE. Nao envie senhas.
5. Exclua do cache/CDN a pagina que gera o iframe/link e as rotas
   /wp-json/vf-fanframe/v1/*. Nunca reutilize um link com ?code=.
6. Logado no WordPress, entre novamente pelo botao do tour. Confira a troca
   com HTTP 200, ok=true e saldo correto. Verifique que recarregar o Fanframe
   valida o token e que repetir o mesmo codigo e recusado com code_consumed.

## Diagnostico no banco externo

Execute no mesmo banco definido por EXT_DB_NAME, nao necessariamente no banco
principal do WordPress:

```sql
SHOW TABLES LIKE 'vf_ff_%';
SHOW COLUMNS FROM vf_ff_app_sessions LIKE 'last_seen_at';
SELECT id, user_id, created_at, expires_at, consumed_at
FROM vf_ff_handoff_codes ORDER BY id DESC LIMIT 5;
```

Ao gerar um link novo, deve aparecer uma linha nova. invalid_code significa
que o registro nao foi encontrado; code_expired e code_consumed sao distintos.
Se a criacao e a troca usam configuracoes EXT_DB_* diferentes, corrija o
ambiente do servidor. Se a pagina usa um link fixo ou cacheado, ela deve chamar
VFFanframe\IframePage::getUrl() novamente para cada acesso autenticado.

## Verificacao desta entrega

Testes em PHP 8.3 com armazenamento SQLite isolado e doubles da API WordPress:
codigo novo, coluna ausente na atualizacao, sessao valida, codigo desconhecido,
consumido/expirado, falha de gravacao, rollback, saldo preservado e status REST.
O original reproduziu: tabela ausente -> codigo devolvido -> invalid_code.
Nao houve acesso ao banco WordPress do site nem instalacao em producao.
Permissoes, configuracao externa, cache e login real precisam ser conferidos
no site pelo administrador. O fluxo de compra/debito nao foi alterado.
